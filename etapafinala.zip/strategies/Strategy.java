package strategies;

import heroes.Hero;

public interface Strategy {
   void changecoef(Hero hero);
}
