package angels;

public interface VisitableAngel {
    void acceptangel(VisitAngel a);
}
